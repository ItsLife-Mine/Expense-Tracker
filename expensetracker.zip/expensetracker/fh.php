
<?php
// echo getcwd();
// chdir("./test1");
// echo"<br/>";
// echo getcwd();
//rmdir("./test2")
// $mydir=opendir("./");
// while($filname=readdir($mydir))
// {
//     if(is_file($filname))
//     echo $filname." is a file <br/>";
//     else
//     echo $filname." is a dir <br/>";
// }
// closedir($mydir);
//unlink("./css/demo.txt");
//copy("./demo2.txt","./css/demo.txt");
//rename("./demo.txt","new demo.txt");
// if(isset($_POST["sbt"]))
// {
// $msg=$_POST["msg"];
// $fp=fopen("./demo.txt","a");
// fputs($fp,$msg);
// fclose($fp);}
?>
<!-- <form method="post">
<label>Enter your message</label>
<textarea name="msg" rows="5" cols="20">
</textarea>
<input type="submit" name="sbt" />
</form> -->


<!-- // while(!feof($rs))
// {
//   $ch=fgetc($rs);
//   if($ch=="\n")
//   echo("<br/>");
//   echo($ch);
// }

// echo("<br/>");
// echo("<br/>");
// rewind($rs);

// while(!feof($rs))
// {
//   $ch=fgets($rs);
//   echo($ch);
//   echo("<br/>");
// }
// echo("<br/>");
// echo("<br/>");
// rewind($rs);
// echo fread($rs,100);
//print_r(file("./demo.txt")); -->