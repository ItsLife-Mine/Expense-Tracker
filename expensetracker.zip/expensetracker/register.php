<?php 
	$conn = mysqli_connect("localhost","root","","expensetracker") or die("connection error");
	if(isset($_POST["search"]))
	{
	
		$email=$_POST["txtemail"];	
		$deleteqry="select fullname,email,mobilenumber,password from user where email='$email'";
		$rs=mysqli_query($conn,$deleteqry);
		$row=mysqli_fetch_array($rs);
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Daily Expense Tracker - Signup</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
<body>
	<div>
		<?php
		include("./includes/header.php");?>
		<?php include_once('includes/sidebar.php');?>

	</div>
	<div>
	<div class="row">
		<div class="
		col-sm-6 offset-sm-4 
		 ">
			<div class="p-3">
				<div class="panel-heading">Sign Up</div>
				<div class="panel-body">
					<form role="form" action="" method="post" id="" name="signup">
						<p style="font-size:16px; color:red" align="center">  </p>
						<fieldset>
							<div class="form-group">
								<input class="form-control" placeholder="Full Name" name="txtname" type="text" value="<?php if(isset($row)){echo $row[0];} ?>" >
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="E-mail" name="txtemail" type="email" value="<?php if(isset($row)){echo $row[1];} ?>" >
							</div>
							<div class="form-group">
								<input type="text" class="form-control" id="txtmobile" name="txtmobile" value="<?php if(isset($row)){echo $row[2];} ?>" placeholder="Mobile Number" maxlength="10" pattern="[0-9]{10}" >
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="txtpassword" value="<?php if(isset($row)){echo $row[3];} ?>"  type="text" value="" >
							</div>
							<div class="form-group">
								<input type="password" class="form-control" id="repeatpassword" name="repeatpassword" placeholder="Repeat Password" >
							</div>
							<div class="checkbox">
								<button type="submit" value="submit" name="insert" class="btn btn-primary">Insert</button>
								<button type="submit" value="submit" name="update" class="btn btn-primary">Update</button>
								<button type="submit" value="submit" name="delete" class="btn btn-primary">Delete</button>
								<button type="submit" value="submit" name="search" class="btn btn-primary">Search</button>
								<button type="submit" value="submit" name="viewall" class="btn btn-primary">View All</button>

								<a href="index.php" class="btn btn-primary">Login</a>
							</div>
							</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>
	</div>
	<div>
		<?php
			include("./includes/footer.php");
			?>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>
</html>

<?php
if(isset($_POST["insert"]))
{
    $name=$_POST["txtname"];
	$email=$_POST["txtemail"];
	$mobilenumber=$_POST["txtmobile"];
	$password=$_POST["txtpassword"];
	$insertqry="insert into user(fullname,email,mobilenumber,password)values('$name','$email',$mobilenumber,'$password')";
	mysqli_query($conn,$insertqry);
}
else if(isset($_POST["delete"]))
{
  
	$email=$_POST["txtemail"];	
	$deleteqry="delete from  user where email='$email'";
	mysqli_query($conn,$deleteqry);
}

else if(isset($_POST["update"]))
{
    $name=$_POST["txtname"];
	$email=$_POST["txtemail"];
	$mobilenumber=$_POST["txtmobile"];
	$password=$_POST["txtpassword"];
	$updateqry="update user set fullname='$name',mobilenumber=$mobilenumber,password='$password' where email='$email'";
	mysqli_query($conn,$updateqry);
}

else if(isset($_POST["viewall"]))
{
		
	$viewall="select fullname,email,mobilenumber,password from user ";
	$rs=mysqli_query($conn,$viewall);
	echo"<table class='table table-dark'>";
	echo"<tr><th>Name</th><th>Email</th><th>Contact</th><th>Password</th></tr>";
	while($row=mysqli_fetch_array($rs))
	{
		echo"<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";

	}
	echo"</table>";
	
}


?>
