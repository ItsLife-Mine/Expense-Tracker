
<nav style="height:20vh" class="navbar navbar-custom navbar-fixed-top bg-dark p-5 " role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="dashboard.php"><h1 class="text-center">Expense Tracker</h1></a>
            </div>
            
        </div>
        <!-- /.container-fluid -->
    </nav>