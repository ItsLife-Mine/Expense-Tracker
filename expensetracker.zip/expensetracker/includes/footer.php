<div style="height:20vh">
				<p class="bg-dark text-white p-5 text-center m-auto">Daily Expense Tracker <a href="#">&copy;Ksg-2024-25</a></p>
</div>